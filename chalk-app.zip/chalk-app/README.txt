Chalk – install on your phone
1. Go to app.netlify.com/drop (free) and drag this whole folder onto the page. Vercel or GitHub Pages work too.
2. Open the https link it gives you on your phone.
3. iPhone (Safari): Share > Add to Home Screen. Android (Chrome): menu > Install app.
It then opens full screen like a normal app and works offline. Data stays on that phone.
